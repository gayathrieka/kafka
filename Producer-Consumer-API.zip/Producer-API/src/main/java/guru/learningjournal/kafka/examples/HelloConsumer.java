package guru.learningjournal.kafka.examples;

import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.serialization.IntegerDeserializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import sun.rmi.runtime.Log;

import java.time.Duration;
import java.util.Collection;
import java.util.Collections;
import java.util.Properties;

public class HelloConsumer {
    private static final Logger Logger_info = LogManager.getLogger();

    public static void main(String[] args) {
        Logger_info.info("Running Consumer");
        Properties props = new Properties();
        props.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, AppConfigs.bootstrapServers);
        props.setProperty(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, IntegerDeserializer.class.getName());
        props.setProperty(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class.getName());
        props.setProperty(ConsumerConfig.GROUP_ID_CONFIG,"my-first-group");
        props.setProperty(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,"earliest");

        //create consumer
        KafkaConsumer<Integer,String> consumer= new KafkaConsumer<Integer, String>(props);

        //subscribe topic

        consumer.subscribe(Collections.singleton(AppConfigs.topicName));

        //poll for new data

        while(true){
        ConsumerRecords<Integer,String> records = consumer.poll(Duration.ofMillis(100));

        for (ConsumerRecord<Integer,String> record : records){
            Logger_info.info("Key:" + record.key() + "Value:" + record.value());
            Logger_info.info("Partition:" + record.partition() + "Offset:" + record.offset());
        }
    }

}

}